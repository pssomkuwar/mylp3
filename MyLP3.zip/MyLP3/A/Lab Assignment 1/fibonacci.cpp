#include <iostream>
using namespace std;

//Fibonacci Series using recursion
int fib_r(int n)
{
	if (n <= 1)
		return n;
	return fib_r(n - 1) + fib_r(n - 2);
}

// Fibonacci Series Using non-recursion

int fib_nr(int n)
{
	int a = 0, b = 1, c, i;
	if (n == 0)
		return a;
	for (i = 2; i <= n; i++) {
		c = a + b;
		a = b;
		b = c;
	}
	return b;
}

int main()
{
	int n,ch;
	cout<<"Find Nth Fibonacci Number (Enter N) : ";
	cin>>n;
	cout<<"1. Recursive()\n2. Non-Recursive\nEnter Choice : ";
	cin>>ch;
	switch(ch) {
		case 1:
			cout << fib_r(n);
			break;
		case 2:
			cout << fib_nr(n);
			break;
	}
	
	return 0;
}

